.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
    "Suggested APA citation: Th\u00e9riault, R. (2023). ",
    "lavaanExtra: Convenience functions ",
    "for lavaan. \nJournal of Open Source Software, 8(90), ",
    "5701. https://doi.org/10.21105/joss.05701"
  )
}
